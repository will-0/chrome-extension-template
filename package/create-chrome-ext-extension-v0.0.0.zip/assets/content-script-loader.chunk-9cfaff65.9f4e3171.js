(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-9cfaff65.js")
    );
  })().catch(console.error);

})();
